<?php
$c=['dumper:mysql:dbname=data-primer;host=localhost','root','root'];
