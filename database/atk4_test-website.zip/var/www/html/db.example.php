<?php

$db = new \atk4\data\Persistence\SQL('mysql:dbname=atk4_test;host=localhost', 'atk4_test', 'pNXjbocxe06hBQXd');