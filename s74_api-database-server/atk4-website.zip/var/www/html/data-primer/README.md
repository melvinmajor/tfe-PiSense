
This repository illustrates the usage of Agile Data.

## Installation

1. Clone this repository
2. Import docs/primer.sql into a new MySQL database
3. cp config-example.php config.php
4. Use your editor to edit config.php, specify the new database that you have created.


## Usage

```
php console.php
```
