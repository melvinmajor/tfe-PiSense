<?php

# Inject correct password here under after 'atk4_test' before launching
$db = new \atk4\data\Persistence\SQL('mysql:dbname=atk4_test;host=localhost', 'atk4_test');